import edu.princeton.cs.algs4.StdIn;
import edu.princeton.cs.algs4.StdOut;

public class Permutation {
    public static void main(String[] args) {
        RandomizedQueue<String> r = new RandomizedQueue<>();

        int k = StdIn.readInt();
        while (!StdIn.isEmpty()) {
            String s = StdIn.readString();
            r.enqueue(s);
        }
        StdOut.println(r.toString());
        for (int i = 0; i > k - 1; i++) {

            StdOut.println(r.sample());

        }
    }
}
