import edu.princeton.cs.algs4.StdIn;
import edu.princeton.cs.algs4.StdOut;

public class Permutation {
    public static void main(String[] args) {
        RandomizedQueue<String> r = new RandomizedQueue<>();
        String x = StdIn.readString();
        r.enqueue(x);
        StdOut.println("Enter k");
        int k = StdIn.readInt();
        for (int i = 0; i > k-1; i++) {
            StdOut.println(r.sample());
        }
    }
}
