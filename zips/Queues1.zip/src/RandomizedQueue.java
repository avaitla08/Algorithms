import edu.princeton.cs.algs4.StdOut;
import edu.princeton.cs.algs4.StdRandom;

import java.util.Iterator;
import java.util.NoSuchElementException;


public class RandomizedQueue<Item> implements Iterable<Item> {
    private Node<Item> head;
    private Node<Item> tail;

    private int n;

    private class Node<Item> {
        private Item item;
        private Node<Item> next;

    }

    public RandomizedQueue() {
        n = 0;
        head = null;
        tail = null;

    }

    public String toString() {
        StringBuilder s = new StringBuilder();
        for (Item item : this)
            s.append(item + " ");
        return s.toString();
    }

    // is the randomized queue empty?
    public boolean isEmpty() {
        return n == 0;
    }

    // return the number of items on the randomized queue
    public int size() {
        return n;
    }

    // add the item
    public void enqueue(Item item) {
        Node<Item> oldlast = tail;
        tail = new Node<Item>();
        tail.item = item;
        tail.next = null;
        if (isEmpty()) head = tail;
        else oldlast.next = tail;
        n++;
    }

    // remove and return a random item
    public Item dequeue() {
        if (isEmpty()) {
            throw new NoSuchElementException("");
        }
        int x = StdRandom.uniformInt(n);
        Node c = head;
        if (!isEmpty()) {
            for (int i = 0; i < x - 1; i++) {
                c = c.next;
            }
            if (c.next != null) {

                c.next = c.next.next;
            }
            n--;

        }
        return head.item;

    }

    // return a random item (but do not remove it)
    public Item sample() {
        if (isEmpty()) {
            throw new NoSuchElementException("");
        }
        int x = StdRandom.uniformInt(n);
        Node current = head;
        for (int i = 0; i < x; i++) {
            current = current.next;
        }

        return (Item) current.item;

    }

    // return an independent iterator over items in random order
    public Iterator<Item> iterator() {
        return new ListIterator();
    }

    private class ListIterator implements Iterator<Item> {
        private RandomizedQueue.Node current = head;

        public boolean hasNext() {
            return current != null;
        }

        public void remove() {
            throw new UnsupportedOperationException("");
        }

        public Item next() {
            if (!hasNext()) {
                throw new NoSuchElementException();
            }
            Item item = (Item) current.item;
            current = current.next;
            return item;
        }
    }


    // unit testing (required)
    public static void main(String[] args) {
        RandomizedQueue<Integer> r = new RandomizedQueue<>();
        r.enqueue(1);
        r.enqueue(2);
        r.enqueue(3);
        r.enqueue(4);
        r.enqueue(5);
        r.enqueue(6);

        StdOut.println("Sample: " + r.sample());

        StdOut.println("New: " + r);
        r.dequeue();
        r.dequeue();
        StdOut.println("Old: " + r);

    }

}



